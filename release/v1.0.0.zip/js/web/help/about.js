window.open("https://github.com/thomaschaplin/snippet-library")
