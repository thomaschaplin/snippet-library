Array.prototype.slice.call (document.styleSheets).map(function(el){el.disabled = true;});
