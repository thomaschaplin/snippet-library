console.log(JSON.stringify(JSON.parse(prompt("Enter JSON to pretty print to console", "")), undefined, 2))
