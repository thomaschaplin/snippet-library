console.log(btoa(prompt("Enter base64 string to decode to the console", "")))
