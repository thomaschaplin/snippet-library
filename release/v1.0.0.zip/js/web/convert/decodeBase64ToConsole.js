console.log(atob(prompt("Enter string to encode to base64 to the console", "")))
