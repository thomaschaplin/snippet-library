console.log(JSON.stringify(JSON.parse(prompt("Enter JSON to minify to console", ""))))
