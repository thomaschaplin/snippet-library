var inputs = document.querySelectorAll('input');
for(let i=0; i<inputs.length; i++)
{
    inputs[i].type = "text";
}
