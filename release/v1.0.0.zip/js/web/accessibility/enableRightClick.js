void(document.oncontextmenu = null)
