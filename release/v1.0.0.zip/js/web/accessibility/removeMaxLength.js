Array.prototype.slice.call (document.querySelectorAll('input')).map(function(el){el.removeAttribute('maxLength')});
