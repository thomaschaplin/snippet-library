location = 'https://downforeveryoneorjustme.com/' + location.hostname
