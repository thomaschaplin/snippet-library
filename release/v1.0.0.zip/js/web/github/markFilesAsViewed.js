document.querySelectorAll('[data-ga-click="File viewed, click, value:false"]').forEach((button) => button.click())
