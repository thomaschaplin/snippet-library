document.querySelectorAll('[data-ga-click="File viewed, click, value:true"]').forEach((button) => button.click())
